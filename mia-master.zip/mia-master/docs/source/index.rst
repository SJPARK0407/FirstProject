===
mia
===

A library for running membership inference attacks (MIA) against machine learning models.

.. include::  ../../README.rst
   :start-after: description-marker-do-not-remove
   :end-before: getting-started-marker-do-not-remove

.. toctree::
   :maxdepth: 2
   :caption: Contents:
    
   quickstart
   usage
   api
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
